# WebView 相关保留
-keep class android.webkit.** { *; }
-keep class com.notebook.app.** { *; }

# JavaScript 接口
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# 保留注解
-keepattributes *Annotation*
-keepattributes JavascriptInterface
