package com.notebook.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;
import android.webkit.ValueCallback;
import android.webkit.WebView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class NativeBridge {

    private final Activity activity;
    private final WebView webView;
    private final ActivityResultLauncher<Intent> importLauncher;

    public NativeBridge(Activity activity, WebView webView,
                       ActivityResultLauncher<Intent> importLauncher) {
        this.activity = activity;
        this.webView = webView;
        this.importLauncher = importLauncher;
    }

    // ========== 导出笔记到 Download 目录 ==========
    @android.webkit.JavascriptInterface
    public void exportNotes(String jsonData) {
        activity.runOnUiThread(() -> {
            try {
                String fileName = "笔记备份_" +
                    new SimpleDateFormat("yyyyMMdd", Locale.CHINA).format(new Date()) + ".json";
                File downloadDir = Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DOWNLOADS);
                if (!downloadDir.exists()) downloadDir.mkdirs();
                File file = new File(downloadDir, fileName);

                try (FileOutputStream fos = new FileOutputStream(file);
                     OutputStreamWriter writer = new OutputStreamWriter(fos, StandardCharsets.UTF_8)) {
                    writer.write(jsonData);
                }

                Toast.makeText(activity, "已导出: " + file.getName(), Toast.LENGTH_LONG).show();
                Log.d("Notebook", "Exported: " + file.getAbsolutePath());

                // 通知媒体库刷新
                Intent scan = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                scan.setData(Uri.fromFile(file));
                activity.sendBroadcast(scan);

            } catch (Exception e) {
                Toast.makeText(activity, "导出失败: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    // ========== 打开文件选择器导入笔记 ==========
    @android.webkit.JavascriptInterface
    public void pickImportFile() {
        activity.runOnUiThread(() -> {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("*/*");
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.putExtra(Intent.EXTRA_MIME_TYPES,
                new String[]{"application/json", "text/plain", "text/json"});
            try {
                importLauncher.launch(intent);
            } catch (Exception e) {
                Toast.makeText(activity, "无法打开文件选择器", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ========== 分享笔记 ==========
    @android.webkit.JavascriptInterface
    public void shareText(String title, String content) {
        activity.runOnUiThread(() -> {
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("text/plain");
            share.putExtra(Intent.EXTRA_SUBJECT, title);
            share.putExtra(Intent.EXTRA_TEXT, content);
            activity.startActivity(Intent.createChooser(share, "分享笔记"));
        });
    }

    // ========== Toast ==========
    @android.webkit.JavascriptInterface
    public void showToast(String msg) {
        activity.runOnUiThread(() -> Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show());
    }

    // ========== 获取 App 版本 ==========
    @android.webkit.JavascriptInterface
    public String getAppVersion() {
        try {
            return activity.getPackageManager()
                .getPackageInfo(activity.getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "1.0.0";
        }
    }

    // ========== 读取导入文件内容 ==========
    public void handleImportResult(Intent data, ValueCallback<String> callback) {
        if (data == null || data.getData() == null) {
            callback.onReceiveValue(null);
            return;
        }
        Uri uri = data.getData();
        try {
            StringBuilder sb = new StringBuilder();
            try (InputStreamReader reader = new InputStreamReader(
                    activity.getContentResolver().openInputStream(uri), StandardCharsets.UTF_8)) {
                char[] buf = new char[4096];
                int n;
                while ((n = reader.read(buf)) > 0) {
                    sb.append(buf, 0, n);
                }
            }
            callback.onReceiveValue(sb.toString());
        } catch (Exception e) {
            callback.onReceiveValue(null);
        }
    }
}
