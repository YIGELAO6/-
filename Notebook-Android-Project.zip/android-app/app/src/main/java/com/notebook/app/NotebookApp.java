package com.notebook.app;

import android.app.Application;
import android.webkit.WebView;

public class NotebookApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        // 启用 WebView 调试（发布版可关闭）
        WebView.setWebContentsDebuggingEnabled(true);
    }
}
